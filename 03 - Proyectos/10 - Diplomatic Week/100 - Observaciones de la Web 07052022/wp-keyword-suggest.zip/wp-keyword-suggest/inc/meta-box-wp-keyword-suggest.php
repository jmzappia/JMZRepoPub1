<div class="wp-keyword-suggest-meta-box-results wp-keyword-suggest-meta-box-section">
		<?php _e('Enter 2-3 word phrases', _PLUGIN_NAME_); ?><br/>
		<input class="wpks-keyword-input" type="text" id="wpks-keyword" name="wpks-keyword" autocomplete="off" placeholder="<?php _e('Enter a keyword', _PLUGIN_NAME_); ?>" value="" tabindex="20001" />
		<input class="button button-primary" id="wpks-suggest" type="button" tabindex="20002" value="<?php _e('Suggest', _PLUGIN_NAME_); ?>" />
</div>

<div id="wpks-suggestions">
</div>