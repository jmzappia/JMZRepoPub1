=== WP Keyword Suggest ===
Contributors: nicolasmarin
Tags: seo, keywords, suggestions, keyword research, tag suggestions, title suggestions, google, yahoo, bing, long tail, post, posts
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 1.2
License: GPLv2 or later

This SEO plugin offers keyword suggestions, taken from autocomplete google, yahoo, bing... up to 250 keywords ideas

== Description ==

With this plugin you will be able to take advantage of long tail keyword so you can learn more about your niche. 
From the list of keywords suggested you can put it directly in the title of your article or add it as a tag. It is very easy to use, from the same page to add item, it shows the widget in the left menu. 
This plugin helps you generate ideas for your post.

For example if you want to write a post about 'Keyword Reasearch Tool', these are tips that shows you:

* Keyword research tool

* Free keyword research tools

* Keyword research tool review

* Google keyword research tools

* Keyword research tool online

* Keyword research seo tool

* Bing keyword research tool

* Keyword research tools 2013

* Keyword research tools list

* Free online keyword research tool

This plugin makes to calls to seowp.es, the first one to create the URLs of the autocomplete service, and the second one to filter and complete the results. Does not require registration.

[Watch a demo](http://www.youtube.com/watch?v=vO64yHrHknA "YouTube")


== Installation ==

Upload the WP Keyword Suggest plugin to your blog, Activate it.

== Screenshots ==

1. Enter a keyword for suggest

== Changelog ==

= 1.2 =
Autocomplete when you enter the keyword.

= 1.1 =
Increase ability to generate keywords ideas.
