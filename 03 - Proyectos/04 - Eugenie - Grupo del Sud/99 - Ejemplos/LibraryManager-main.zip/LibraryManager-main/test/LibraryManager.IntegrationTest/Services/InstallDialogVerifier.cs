﻿using Microsoft.Test.Apex.VisualStudio;

namespace Microsoft.Web.LibraryManager.IntegrationTest.Services
{
    public class InstallDialogVerifier : VisualStudioInProcessTestExtensionVerifier
    {
    }
}
