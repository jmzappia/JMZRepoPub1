﻿using System.Resources;
using System.Runtime.CompilerServices;

[assembly: NeutralResourcesLanguage("en")]
[assembly: InternalsVisibleTo("libman")]
[assembly: InternalsVisibleTo("Microsoft.Web.LibraryManager.Build")]
[assembly: InternalsVisibleTo("Microsoft.Web.LibraryManager.IntegrationTest")]
[assembly: InternalsVisibleTo("Microsoft.Web.LibraryManager.Test")]
[assembly: InternalsVisibleTo("Microsoft.Web.LibraryManager.Vsix")]
[assembly: InternalsVisibleTo("Microsoft.Web.LibraryManager.Vsix.Test")]
