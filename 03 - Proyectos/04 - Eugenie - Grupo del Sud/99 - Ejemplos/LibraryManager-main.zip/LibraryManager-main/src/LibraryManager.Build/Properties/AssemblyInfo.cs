﻿using System.Resources;
using System.Runtime.CompilerServices;

[assembly: NeutralResourcesLanguage("en")]
[assembly:InternalsVisibleTo("Microsoft.Web.LibraryManager.Build.Test")]