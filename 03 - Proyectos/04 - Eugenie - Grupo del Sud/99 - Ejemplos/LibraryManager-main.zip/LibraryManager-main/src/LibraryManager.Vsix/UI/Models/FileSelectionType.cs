﻿namespace Microsoft.Web.LibraryManager.Vsix.UI.Models
{
    internal enum FileSelectionType
    {
        InstallAllLibraryFiles,
        ChooseSpecificFilesToInstall
    }
}
