﻿namespace Microsoft.Web.LibraryManager.Vsix.UI.Models
{
    internal static class FileSelection
    {
        public static FileSelectionType InstallationType { get; set; }
    }
}
