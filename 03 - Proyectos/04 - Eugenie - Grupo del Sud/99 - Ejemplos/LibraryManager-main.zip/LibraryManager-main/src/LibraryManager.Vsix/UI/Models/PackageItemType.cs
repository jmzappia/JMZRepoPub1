namespace Microsoft.Web.LibraryManager.Vsix.UI.Models
{
    public enum PackageItemType
    {
        Folder,
        File
    }
}