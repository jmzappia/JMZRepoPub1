Summary of the changes
 - Detail 1
 - Detail 2

Resolves #bugnumber
